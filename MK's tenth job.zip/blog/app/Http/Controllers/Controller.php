<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use phpDocumentor\Reflection\DocBlock\Tags\Uses;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
}
class UserController extends Controller{
    public function setReturn($code){
        $message=array(
            0=>'success',
            1=>'fail',
            2=>'undefined index',
            3=>'email_exists',
            4=>'user_non_existent',
            5=>'password_error',
            6=>'username_exists'
        );
        $result=array(
            'code'=>$code,
            'message'=>$message[$code]
        );
        return json_encode($result,JSON_UNESCAPED_UNICODE);
    }
    public function register(){
        $username=$_POST["username"];
        $password=$_POST["password"];
        $email=$_POST["email"];
        if($username=''||$password=''||$email=''){
            return $this->setReturn(2);
        }
        else{
            $is_username=User::where('username', $username)->exists();
            if($is_username){
                return $this->setReturn(6);
        }
            $is_email=User::where('email',$email)->exists();
            if($is_email){
                return $this->setReturn(3);
            }
            else{
                $res=User::create(['username'=>$username,'password'=>$password,'email'=>$email]);
                if($res){
                    return $this->setReturn(0);
                }
                else{
                    return $this->setReturn(1);
                }
            }

        }
    }
    public function login(){
        $username=$_POST["username"];
        $password=$_POST["password"];
        if($username=''||$password=''||$email=''){
            return $this->setReturn(2);
        }
        $result=User::where('username',$username)->exists();
        if($result){
            $pwd=User::where('username',$username)->value('password');
            if($pwd==$password){
                return $this->setReturn(0);
            }
            else{
                return $this->setReturn(5);
            }
        }
        else{
            return $this->setReturn(4);
        }




    }




}
